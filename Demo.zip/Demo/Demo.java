import java.applet.*;
import java.awt.*;


public class Demo extends Applet{

        
	private int w, h;
        public void init( )
        {
        	w = 45;
        	h = 50;
        }
    
        public void paint(Graphics g)
        {
        	g.drawRect(w, h, 20, 80);
        }

	//System.out.println("Hellllo");
        
   
}